﻿---
external help file: NLogModule-help.xml
online version: 
schema: 2.0.0
---

# Get-NewLogConfig

## SYNOPSIS
Creates a new configuration in memory

## SYNTAX

```
Get-NewLogConfig
```

## DESCRIPTION
Important to add logging behaviour and log targets to your LogManager

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
$myLogconfig = Get-NewLogConfig()
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

