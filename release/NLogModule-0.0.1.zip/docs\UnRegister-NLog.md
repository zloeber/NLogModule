---
external help file: NLogModule-help.xml
online version: 
schema: 2.0.0
---

# UnRegister-NLog
## SYNOPSIS
UnRegister the NLog Target..

## SYNTAX

```
UnRegister-NLog
```

## DESCRIPTION
UnRegister the NLog Target..

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
UnRegister-NLog
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

