---
external help file: NLogModule-help.xml
online version: 
schema: 2.0.0
---

# Get-NLogDllLoadState
## SYNOPSIS
Validate if the NLog Dll is loaded or not.

## SYNTAX

```
Get-NLogDllLoadState
```

## DESCRIPTION
Validate if the NLog Dll is loaded or not.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Get-NLogDllLoadState
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS

